import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];// 1. Importamos useEffect junto a useState
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f1ab0bd5";
import "/src/App.css";
import Header from "/src/components/Header.tsx";
import TaskInput from "/src/components/TaskInput.tsx";
import TaskList from "/src/components/TaskList.tsx";
import Footer from "/src/components/Footer.tsx";
import Bienvenida from "/src/components/Bienvenida.tsx";
var _jsxFileName = "C:/Users/herli/task-manager-react/frontend/src/App.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f1ab0bd5";
var _s = $RefreshSig$();
function App() {
	_s();
	const [tasks, setTasks] = useState([]);
	// 🛡️ ESTADO DE SEGURIDAD: Reemplazamos el menú por un verdadero candado
	const [isLogged, setIsLogged] = useState(true);
	// 1. Al iniciar la app, el "guardia" verifica si ya hay un token válido guardado
	useEffect(() => {
		const token = localStorage.getItem("token");
		if (token) {
			setIsLogged(true);
		}
	}, []);
	// 2. CARGAR TAREAS (¡Ahora solo las busca si el usuario tiene permiso!)
	useEffect(() => {
		if (!isLogged) return;
		const fetchTasks = async () => {
			try {
				const response = await fetch("http://localhost:3000/tasks");
				const data = await response.json();
				setTasks(data);
			} catch (error) {
				console.error("Error al cargar tareas:", error);
			}
		};
		fetchTasks();
	}, [isLogged]);
	// --- TUS FUNCIONES DEL GESTOR (Se quedan exactamente igual) ---
	const addTask = async (text) => {
		try {
			const response = await fetch("http://localhost:3000/tasks", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({ text })
			});
			const newTask = await response.json();
			setTasks([...tasks, newTask]);
		} catch (error) {
			console.error("Error al agregar tarea:", error);
		}
	};
	const deleteTask = (id) => {
		fetch(`http://localhost:3000/tasks/${id}`, { method: "DELETE" }).then((response) => {
			if (!response.ok) throw new Error("Error al eliminar");
			const updatedTasks = tasks.filter((task) => task.id !== id);
			setTasks(updatedTasks);
		}).catch((error) => console.error("Error:", error));
	};
	const toggleTask = (id) => {
		const updatedTasks = tasks.map((task) => {
			if (task.id === id) return {
				...task,
				completed: !task.completed
			};
			return task;
		});
		setTasks(updatedTasks);
	};
	const completedTasks = tasks.filter((task) => task.completed).length;
	const pendingTasks = tasks.length - completedTasks;
	// 3. FUNCIÓN PARA CERRAR SESIÓN
	const handleLogout = () => {
		localStorage.removeItem("token");
		setIsLogged(false);
		setTasks([]);
	};
	// RENDERIZADO CONDICIONAL ESTRICTO (El Bloqueo)
	// Si NO está logueado, mostramos el login (Y le pasamos la llave para abrir el candado)
	if (!isLogged) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "app-container",
			children: /* @__PURE__ */ _jsxDEV(Bienvenida, { onLogin: () => setIsLogged(true) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 98,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 96,
			columnNumber: 7
		}, this);
	}
	// Si SÍ está logueado, le mostramos su Gestor de Tareas y el botón de Salir
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "app-container",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				style: {
					display: "flex",
					justifyContent: "flex-end",
					marginBottom: "15px"
				},
				children: /* @__PURE__ */ _jsxDEV("button", {
					onClick: handleLogout,
					style: {
						padding: "8px 15px",
						background: "#dc3545",
						color: "white",
						border: "none",
						borderRadius: "5px",
						cursor: "pointer",
						fontWeight: "bold"
					},
					children: "🚪 Cerrar Sesión"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 107,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Header, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 116,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(TaskInput, { onAddTask: addTask }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(TaskList, {
				tasks,
				onDeleteTask: deleteTask,
				onToggleTask: toggleTask
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Footer, {
				total: tasks.length,
				completed: completedTasks,
				pending: pendingTasks
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 123,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 105,
		columnNumber: 5
	}, this);
}
_s(App, "MqOxPzhxd1bOKHCY+OcE90T9QEg=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/herli/task-manager-react/frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/herli/task-manager-react/frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/herli/task-manager-react/frontend/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IjtBQUNBLFNBQVMsVUFBVSxpQkFBaUI7QUFDcEMsT0FBTztBQUNQLE9BQU8sWUFBWTtBQUNuQixPQUFPLGVBQWU7QUFDdEIsT0FBTyxjQUFjO0FBQ3JCLE9BQU8sWUFBWTtBQUNuQixPQUFPLGdCQUFnQjs7OztBQVN2QixTQUFTLE1BQU07O0NBQ2IsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFpQixDQUFDLENBQUM7O0NBRzdDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxJQUFJOztDQUc3QyxnQkFBZ0I7RUFDZCxNQUFNLFFBQVEsYUFBYSxRQUFRLE9BQU87RUFDMUMsSUFBSSxPQUFPO0dBQ1QsWUFBWSxJQUFJO0VBQ2xCO0NBQ0YsR0FBRyxDQUFDLENBQUM7O0NBR0wsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLFVBQVU7RUFFZixNQUFNLGFBQWEsWUFBWTtHQUM3QixJQUFJO0lBQ0YsTUFBTSxXQUFXLE1BQU0sTUFBTSw2QkFBNkI7SUFDMUQsTUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLO0lBQ2pDLFNBQVMsSUFBSTtHQUNmLFNBQVMsT0FBTztJQUNkLFFBQVEsTUFBTSwyQkFBMkIsS0FBSztHQUNoRDtFQUNGO0VBQ0EsV0FBVztDQUNiLEdBQUcsQ0FBQyxRQUFRLENBQUM7O0NBR2IsTUFBTSxVQUFVLE9BQU8sU0FBaUI7RUFDdEMsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLE1BQU0sK0JBQStCO0lBQzFELFFBQVE7SUFDUixTQUFTLEVBQUUsZ0JBQWdCLG1CQUFtQjtJQUM5QyxNQUFNLEtBQUssVUFBVSxFQUFRLEtBQUssQ0FBQztHQUNyQyxDQUFDO0dBQ0QsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLO0dBQ3BDLFNBQVMsQ0FBQyxHQUFHLE9BQU8sT0FBTyxDQUFDO0VBQzlCLFNBQVMsT0FBTztHQUNkLFFBQVEsTUFBTSwyQkFBMkIsS0FBSztFQUNoRDtDQUNGO0NBRUEsTUFBTSxjQUFjLE9BQWU7RUFDakMsTUFBTSwrQkFBK0IsTUFBTSxFQUFFLFFBQVEsU0FBUyxDQUFDLEVBQzVELE1BQU0sYUFBYTtHQUNsQixJQUFJLENBQUMsU0FBUyxJQUFJLE1BQU0sSUFBSSxNQUFNLG1CQUFtQjtHQUNyRCxNQUFNLGVBQWUsTUFBTSxRQUFRLFNBQVMsS0FBSyxPQUFPLEVBQUU7R0FDMUQsU0FBUyxZQUFZO0VBQ3ZCLENBQUMsRUFDQSxPQUFPLFVBQVUsUUFBUSxNQUFNLFVBQVUsS0FBSyxDQUFDO0NBQ3BEO0NBRUEsTUFBTSxjQUFjLE9BQWU7RUFDakMsTUFBTSxlQUFlLE1BQU0sS0FBSyxTQUFTO0dBQ3ZDLElBQUksS0FBSyxPQUFPLElBQUksT0FBTztJQUFFLEdBQUc7SUFBTSxXQUFXLENBQUMsS0FBSztHQUFVO0dBQ2pFLE9BQU87RUFDVCxDQUFDO0VBQ0QsU0FBUyxZQUFZO0NBQ3ZCO0NBRUEsTUFBTSxpQkFBaUIsTUFBTSxRQUFRLFNBQVMsS0FBSyxTQUFTLEVBQUU7Q0FDOUQsTUFBTSxlQUFlLE1BQU0sU0FBUzs7Q0FHcEMsTUFBTSxxQkFBcUI7RUFDekIsYUFBYSxXQUFXLE9BQU87RUFDL0IsWUFBWSxLQUFLO0VBQ2pCLFNBQVMsQ0FBQyxDQUFDO0NBQ2I7OztDQU1BLElBQUksQ0FBQyxVQUFVO0VBQ2IsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUViLHdCQUFDLFlBQUQsRUFBWSxlQUFlLFlBQVksSUFBSSxFQUFJOzs7OztFQUM1Qzs7Ozs7Q0FFVDs7Q0FHQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssT0FBTztLQUFFLFNBQVM7S0FBUSxnQkFBZ0I7S0FBWSxjQUFjO0lBQU87Y0FDOUUsd0JBQUMsVUFBRDtLQUNFLFNBQVM7S0FDVCxPQUFPO01BQUUsU0FBUztNQUFZLFlBQVk7TUFBVyxPQUFPO01BQVMsUUFBUTtNQUFRLGNBQWM7TUFBTyxRQUFRO01BQVcsWUFBWTtLQUFPO2VBQ2pKO0lBRU87Ozs7O0dBQ0w7Ozs7O0dBRUwsd0JBQUMsUUFBRCxDQUFTOzs7OztHQUNULHdCQUFDLFdBQUQsRUFBVyxXQUFXLFFBQVU7Ozs7O0dBQ2hDLHdCQUFDLFVBQUQ7SUFDUztJQUNQLGNBQWM7SUFDZCxjQUFjO0dBQ2Y7Ozs7O0dBQ0Qsd0JBQUMsUUFBRDtJQUNFLE9BQU8sTUFBTTtJQUNiLFdBQVc7SUFDWCxTQUFTO0dBQ1Y7Ozs7O0VBQ0U7Ozs7OztBQUVUOzs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLy8gMS4gSW1wb3J0YW1vcyB1c2VFZmZlY3QganVudG8gYSB1c2VTdGF0ZVxuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IFwiLi9BcHAuY3NzXCI7XG5pbXBvcnQgSGVhZGVyIGZyb20gXCIuL2NvbXBvbmVudHMvSGVhZGVyXCI7XG5pbXBvcnQgVGFza0lucHV0IGZyb20gXCIuL2NvbXBvbmVudHMvVGFza0lucHV0XCI7XG5pbXBvcnQgVGFza0xpc3QgZnJvbSBcIi4vY29tcG9uZW50cy9UYXNrTGlzdFwiO1xuaW1wb3J0IEZvb3RlciBmcm9tIFwiLi9jb21wb25lbnRzL0Zvb3RlclwiO1xuaW1wb3J0IEJpZW52ZW5pZGEgZnJvbSBcIi4vY29tcG9uZW50cy9CaWVudmVuaWRhXCI7IFxuXG50eXBlIFRhc2sgPSB7XG4gIGlkOiBudW1iZXI7XG4gIHRleHQ6IHN0cmluZztcbiAgY29tcGxldGVkOiBib29sZWFuO1xuICBjcmVhdGVkQXQ/OiBzdHJpbmc7IFxufTtcblxuZnVuY3Rpb24gQXBwKCkge1xuICBjb25zdCBbdGFza3MsIHNldFRhc2tzXSA9IHVzZVN0YXRlPFRhc2tbXT4oW10pO1xuICBcbiAgLy8g8J+boe+4jyBFU1RBRE8gREUgU0VHVVJJREFEOiBSZWVtcGxhemFtb3MgZWwgbWVuw7ogcG9yIHVuIHZlcmRhZGVybyBjYW5kYWRvXG4gIGNvbnN0IFtpc0xvZ2dlZCwgc2V0SXNMb2dnZWRdID0gdXNlU3RhdGUodHJ1ZSk7XG5cbiAgLy8gMS4gQWwgaW5pY2lhciBsYSBhcHAsIGVsIFwiZ3VhcmRpYVwiIHZlcmlmaWNhIHNpIHlhIGhheSB1biB0b2tlbiB2w6FsaWRvIGd1YXJkYWRvXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgdG9rZW4gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInRva2VuXCIpO1xuICAgIGlmICh0b2tlbikge1xuICAgICAgc2V0SXNMb2dnZWQodHJ1ZSk7IC8vIMKhUGFzZSBsaWJyZSwgeWEgZXN0YWJhIGxvZ3VlYWRvIVxuICAgIH1cbiAgfSwgW10pO1xuXG4gIC8vIDIuIENBUkdBUiBUQVJFQVMgKMKhQWhvcmEgc29sbyBsYXMgYnVzY2Egc2kgZWwgdXN1YXJpbyB0aWVuZSBwZXJtaXNvISlcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWlzTG9nZ2VkKSByZXR1cm47IC8vIFNpIG5vIGVzdMOhIGxvZ3VlYWRvLCBkZXRlbmVtb3MgbGEgZnVuY2nDs24gYXF1w61cblxuICAgIGNvbnN0IGZldGNoVGFza3MgPSBhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFwiaHR0cDovL2xvY2FsaG9zdDozMDAwL3Rhc2tzXCIpO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBzZXRUYXNrcyhkYXRhKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBhbCBjYXJnYXIgdGFyZWFzOlwiLCBlcnJvcik7XG4gICAgICB9XG4gICAgfTtcbiAgICBmZXRjaFRhc2tzKCk7XG4gIH0sIFtpc0xvZ2dlZF0pOyAvLyBFc3RlIHVzZUVmZmVjdCBzZSB2dWVsdmUgYSBkaXNwYXJhciBlbiBjdWFudG8gaXNMb2dnZWQgY2FtYmlhIGEgdHJ1ZVxuXG4gIC8vIC0tLSBUVVMgRlVOQ0lPTkVTIERFTCBHRVNUT1IgKFNlIHF1ZWRhbiBleGFjdGFtZW50ZSBpZ3VhbCkgLS0tXG4gIGNvbnN0IGFkZFRhc2sgPSBhc3luYyAodGV4dDogc3RyaW5nKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goXCJodHRwOi8vbG9jYWxob3N0OjMwMDAvdGFza3NcIiwge1xuICAgICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgdGV4dDogdGV4dCB9KVxuICAgICAgfSk7XG4gICAgICBjb25zdCBuZXdUYXNrID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgc2V0VGFza3MoWy4uLnRhc2tzLCBuZXdUYXNrXSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBhbCBhZ3JlZ2FyIHRhcmVhOlwiLCBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGRlbGV0ZVRhc2sgPSAoaWQ6IG51bWJlcikgPT4ge1xuICAgIGZldGNoKGBodHRwOi8vbG9jYWxob3N0OjMwMDAvdGFza3MvJHtpZH1gLCB7IG1ldGhvZDogXCJERUxFVEVcIiB9KVxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHRocm93IG5ldyBFcnJvcihcIkVycm9yIGFsIGVsaW1pbmFyXCIpO1xuICAgICAgICBjb25zdCB1cGRhdGVkVGFza3MgPSB0YXNrcy5maWx0ZXIoKHRhc2spID0+IHRhc2suaWQgIT09IGlkKTtcbiAgICAgICAgc2V0VGFza3ModXBkYXRlZFRhc2tzKTtcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiBjb25zb2xlLmVycm9yKFwiRXJyb3I6XCIsIGVycm9yKSk7XG4gIH07XG5cbiAgY29uc3QgdG9nZ2xlVGFzayA9IChpZDogbnVtYmVyKSA9PiB7XG4gICAgY29uc3QgdXBkYXRlZFRhc2tzID0gdGFza3MubWFwKCh0YXNrKSA9PiB7XG4gICAgICBpZiAodGFzay5pZCA9PT0gaWQpIHJldHVybiB7IC4uLnRhc2ssIGNvbXBsZXRlZDogIXRhc2suY29tcGxldGVkIH07XG4gICAgICByZXR1cm4gdGFzaztcbiAgICB9KTtcbiAgICBzZXRUYXNrcyh1cGRhdGVkVGFza3MpO1xuICB9O1xuXG4gIGNvbnN0IGNvbXBsZXRlZFRhc2tzID0gdGFza3MuZmlsdGVyKCh0YXNrKSA9PiB0YXNrLmNvbXBsZXRlZCkubGVuZ3RoO1xuICBjb25zdCBwZW5kaW5nVGFza3MgPSB0YXNrcy5sZW5ndGggLSBjb21wbGV0ZWRUYXNrcztcblxuICAvLyAzLiBGVU5DScOTTiBQQVJBIENFUlJBUiBTRVNJw5NOXG4gIGNvbnN0IGhhbmRsZUxvZ291dCA9ICgpID0+IHtcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShcInRva2VuXCIpOyAvLyBCb3JyYW1vcyBsYSBjcmVkZW5jaWFsXG4gICAgc2V0SXNMb2dnZWQoZmFsc2UpOyAgICAgICAgICAgICAgIC8vIFBvbmVtb3MgZWwgY2FuZGFkb1xuICAgIHNldFRhc2tzKFtdKTsgICAgICAgICAgICAgICAgICAgICAvLyBCb3JyYW1vcyBsYXMgdGFyZWFzIGRlIGxhIHBhbnRhbGxhIHBvciBzZWd1cmlkYWRcbiAgfTtcblxuXG4gIC8vIFJFTkRFUklaQURPIENPTkRJQ0lPTkFMIEVTVFJJQ1RPIChFbCBCbG9xdWVvKVxuXG4gIC8vIFNpIE5PIGVzdMOhIGxvZ3VlYWRvLCBtb3N0cmFtb3MgZWwgbG9naW4gKFkgbGUgcGFzYW1vcyBsYSBsbGF2ZSBwYXJhIGFicmlyIGVsIGNhbmRhZG8pXG4gIGlmICghaXNMb2dnZWQpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhcHAtY29udGFpbmVyXCI+XG4gICAgICAgIHsvKiBBcXXDrSBjb25lY3RhbW9zIGVsIGV2ZW50byBvbkxvZ2luIHF1ZSBwcm9ncmFtYXN0ZSBlbiBlbCBwYXNvIGFudGVyaW9yICovfVxuICAgICAgICA8QmllbnZlbmlkYSBvbkxvZ2luPXsoKSA9PiBzZXRJc0xvZ2dlZCh0cnVlKX0gLz5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICAvLyBTaSBTw40gZXN0w6EgbG9ndWVhZG8sIGxlIG1vc3RyYW1vcyBzdSBHZXN0b3IgZGUgVGFyZWFzIHkgZWwgYm90w7NuIGRlIFNhbGlyXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhcHAtY29udGFpbmVyXCI+XG4gICAgICB7LyogQmFycmEgc3VwZXJpb3IgZGUgc2VzacOzbiAqL31cbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcImZsZXgtZW5kXCIsIG1hcmdpbkJvdHRvbTogXCIxNXB4XCIgfX0+XG4gICAgICAgIDxidXR0b24gXG4gICAgICAgICAgb25DbGljaz17aGFuZGxlTG9nb3V0fVxuICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiOHB4IDE1cHhcIiwgYmFja2dyb3VuZDogXCIjZGMzNTQ1XCIsIGNvbG9yOiBcIndoaXRlXCIsIGJvcmRlcjogXCJub25lXCIsIGJvcmRlclJhZGl1czogXCI1cHhcIiwgY3Vyc29yOiBcInBvaW50ZXJcIiwgZm9udFdlaWdodDogXCJib2xkXCIgfX1cbiAgICAgICAgPlxuICAgICAgICAgIPCfmqogQ2VycmFyIFNlc2nDs25cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPEhlYWRlciAvPlxuICAgICAgPFRhc2tJbnB1dCBvbkFkZFRhc2s9e2FkZFRhc2t9IC8+XG4gICAgICA8VGFza0xpc3QgXG4gICAgICAgIHRhc2tzPXt0YXNrc30gXG4gICAgICAgIG9uRGVsZXRlVGFzaz17ZGVsZXRlVGFza30gXG4gICAgICAgIG9uVG9nZ2xlVGFzaz17dG9nZ2xlVGFza30gXG4gICAgICAvPlxuICAgICAgPEZvb3RlciBcbiAgICAgICAgdG90YWw9e3Rhc2tzLmxlbmd0aH0gXG4gICAgICAgIGNvbXBsZXRlZD17Y29tcGxldGVkVGFza3N9IFxuICAgICAgICBwZW5kaW5nPXtwZW5kaW5nVGFza3N9IFxuICAgICAgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwOyJdfQ==