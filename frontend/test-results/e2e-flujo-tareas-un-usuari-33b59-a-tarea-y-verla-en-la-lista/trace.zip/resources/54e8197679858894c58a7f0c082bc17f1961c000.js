import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TaskList.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import TaskCard from "/src/components/TaskCard.tsx";
import EmptyState from "/src/components/EmptyState.tsx";
var _jsxFileName = "C:/Users/herli/task-manager-react/frontend/src/components/TaskList.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f1ab0bd5";
function TaskList({ tasks, onDeleteTask, onToggleTask }) {
	// RENDERIZADO CONDICIONAL: Si el arreglo está vacío, detenemos la función aquí
	// y mostramos el componente de "No hay tareas"
	if (tasks.length === 0) {
		return /* @__PURE__ */ _jsxDEV(EmptyState, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 12
		}, this);
	}
	// Si hay tareas, procedemos a dibujarlas en una lista ordenada
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "task-list",
		children: tasks.map((task) => /* @__PURE__ */ _jsxDEV(TaskCard, {
			task,
			onDeleteTask,
			onToggleTask
		}, task.id, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 5
	}, this);
}
_c = TaskList;
export default TaskList;
var _c;
$RefreshReg$(_c, "TaskList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/TaskList.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/herli/task-manager-react/frontend/src/components/TaskList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/herli/task-manager-react/frontend/src/components/TaskList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/herli/task-manager-react/frontend/src/components/TaskList.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxjQUFjO0FBQ3JCLE9BQU8sZ0JBQWdCOzs7QUFldkIsU0FBUyxTQUFTLEVBQUUsT0FBTyxjQUFjLGdCQUErQjs7O0NBR3RFLElBQUksTUFBTSxXQUFXLEdBQUc7RUFDdEIsT0FBTyx3QkFBQyxZQUFELENBQWE7Ozs7O0NBQ3RCOztDQUdBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDWixNQUFNLEtBQUssU0FDVix3QkFBQyxVQUFEO0dBRVE7R0FDUTtHQUNBO0VBQ2YsR0FKTSxLQUFLOzs7O1NBSVgsQ0FDRjtDQUNFOzs7OztBQUVUOztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVGFza0xpc3QudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBUYXNrQ2FyZCBmcm9tIFwiLi9UYXNrQ2FyZFwiO1xyXG5pbXBvcnQgRW1wdHlTdGF0ZSBmcm9tIFwiLi9FbXB0eVN0YXRlXCI7IFxyXG5cclxudHlwZSBUYXNrID0ge1xyXG4gIGlkOiBudW1iZXI7XHJcbiAgdGV4dDogc3RyaW5nO1xyXG4gIGNvbXBsZXRlZDogYm9vbGVhbjtcclxufTtcclxuXHJcbi8vIERlY2xhcmFtb3MgcXXDqSBkYXRvcyBlc3TDoSBvYmxpZ2FkbyBhIHJlY2liaXIgZXN0ZSBjb21wb25lbnRlIGRlc2RlIEFwcC50c3hcclxudHlwZSBUYXNrTGlzdFByb3BzID0ge1xyXG4gIHRhc2tzOiBUYXNrW107XHJcbiAgb25EZWxldGVUYXNrOiAoaWQ6IG51bWJlcikgPT4gdm9pZDtcclxuICBvblRvZ2dsZVRhc2s6IChpZDogbnVtYmVyKSA9PiB2b2lkO1xyXG59O1xyXG5cclxuZnVuY3Rpb24gVGFza0xpc3QoeyB0YXNrcywgb25EZWxldGVUYXNrLCBvblRvZ2dsZVRhc2sgfTogVGFza0xpc3RQcm9wcykge1xyXG4gIC8vIFJFTkRFUklaQURPIENPTkRJQ0lPTkFMOiBTaSBlbCBhcnJlZ2xvIGVzdMOhIHZhY8OtbywgZGV0ZW5lbW9zIGxhIGZ1bmNpw7NuIGFxdcOtXHJcbiAgLy8geSBtb3N0cmFtb3MgZWwgY29tcG9uZW50ZSBkZSBcIk5vIGhheSB0YXJlYXNcIlxyXG4gIGlmICh0YXNrcy5sZW5ndGggPT09IDApIHtcclxuICAgIHJldHVybiA8RW1wdHlTdGF0ZSAvPjtcclxuICB9XHJcblxyXG4gIC8vIFNpIGhheSB0YXJlYXMsIHByb2NlZGVtb3MgYSBkaWJ1amFybGFzIGVuIHVuYSBsaXN0YSBvcmRlbmFkYVxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInRhc2stbGlzdFwiPlxyXG4gICAgICB7dGFza3MubWFwKCh0YXNrKSA9PiAoXHJcbiAgICAgICAgPFRhc2tDYXJkXHJcbiAgICAgICAgICBrZXk9e3Rhc2suaWR9IC8vIFJlcXVpc2l0byBkZSBSZWFjdCBwYXJhIHNhYmVyIHF1w6kgZWxlbWVudG8gZXMgY3XDoWwgZW4gZWwgRE9NXHJcbiAgICAgICAgICB0YXNrPXt0YXNrfVxyXG4gICAgICAgICAgb25EZWxldGVUYXNrPXtvbkRlbGV0ZVRhc2t9XHJcbiAgICAgICAgICBvblRvZ2dsZVRhc2s9e29uVG9nZ2xlVGFza31cclxuICAgICAgICAvPlxyXG4gICAgICApKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRhc2tMaXN0O1xyXG4iXX0=