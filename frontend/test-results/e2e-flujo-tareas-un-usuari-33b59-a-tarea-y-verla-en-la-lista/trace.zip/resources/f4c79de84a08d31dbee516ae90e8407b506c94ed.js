import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TaskInput.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f1ab0bd5";
var _jsxFileName = "C:/Users/herli/task-manager-react/frontend/src/components/TaskInput.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f1ab0bd5";
var _s = $RefreshSig$();
function TaskInput(props) {
	_s();
	const [text, setText] = useState("");
	const handleSubmit = () => {
		if (text.trim() === "") {
			return;
		}
		props.onAddTask(text);
		setText("");
	};
	return /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("input", {
		type: "text",
		placeholder: "Escribir una nueva tarea",
		value: text,
		onChange: (event) => setText(event.target.value)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 21,
		columnNumber: 13
	}, this), /* @__PURE__ */ _jsxDEV("button", {
		onClick: handleSubmit,
		children: "Agregar"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 13
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 9
	}, this);
}
_s(TaskInput, "3t0DFnMi16eB/7p7iIKtjG5r68g=");
_c = TaskInput;
export default TaskInput;
var _c;
$RefreshReg$(_c, "TaskInput");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/TaskInput.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/herli/task-manager-react/frontend/src/components/TaskInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/herli/task-manager-react/frontend/src/components/TaskInput.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/herli/task-manager-react/frontend/src/components/TaskInput.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUSxnQkFBZTs7OztBQU12QixTQUFTLFVBQVUsT0FBdUI7O0NBQ3RDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxFQUFFO0NBRW5DLE1BQU0scUJBQXFCO0VBQ3ZCLElBQUksS0FBSyxLQUFLLE1BQU0sSUFBSTtHQUNwQjtFQUNKO0VBRUEsTUFBTSxVQUFVLElBQUk7RUFDcEIsUUFBUSxFQUFFO0NBQ2Q7Q0FFQSxPQUNJLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxTQUFEO0VBQ0ksTUFBSztFQUNMLGFBQVk7RUFDWixPQUFPO0VBQ1AsV0FBVyxVQUFVLFFBQVEsTUFBTSxPQUFPLEtBQUs7Q0FDbEQ7Ozs7V0FDRCx3QkFBQyxVQUFEO0VBQVEsU0FBUztZQUFjO0NBRXZCOzs7O1NBQ1A7Ozs7O0FBRWI7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVGFza0lucHV0LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge3VzZVN0YXRlfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbnR5cGUgVGFza0lucHV0UHJvcHMgPSB7XHJcbiAgICBvbkFkZFRhc2s6ICh0YXNrVGV4dDogc3RyaW5nKSA9PiB2b2lkO1xyXG59O1xyXG5cclxuZnVuY3Rpb24gVGFza0lucHV0KHByb3BzOiBUYXNrSW5wdXRQcm9wcykge1xyXG4gICAgY29uc3QgW3RleHQsIHNldFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlU3VibWl0ID0gKCkgPT4ge1xyXG4gICAgICAgIGlmICh0ZXh0LnRyaW0oKSA9PT0gXCJcIikge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwcm9wcy5vbkFkZFRhc2sodGV4dCk7XHJcbiAgICAgICAgc2V0VGV4dChcIlwiKTtcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRXNjcmliaXIgdW5hIG51ZXZhIHRhcmVhXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXt0ZXh0fVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0VGV4dChldmVudC50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZVN1Ym1pdH0+XHJcbiAgICAgICAgICAgICAgICBBZ3JlZ2FyXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxufSAgIFxyXG5cclxuZXhwb3J0IGRlZmF1bHQgVGFza0lucHV0OyJdfQ==