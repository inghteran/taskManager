import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Footer.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/herli/task-manager-react/frontend/src/components/Footer.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f1ab0bd5";
function Footer({ total, completed, pending }) {
	return /* @__PURE__ */ _jsxDEV("footer", {
		className: "app-footer",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "footer-stat",
				children: ["Total: ", /* @__PURE__ */ _jsxDEV("span", { children: total }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 10,
					columnNumber: 43
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 10,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "footer-stat",
				children: ["Completadas: ", /* @__PURE__ */ _jsxDEV("span", {
					className: "stat-done",
					children: completed
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 11,
					columnNumber: 49
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "footer-stat",
				children: ["Pendientes: ", /* @__PURE__ */ _jsxDEV("span", {
					className: "stat-pending",
					children: pending
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 12,
					columnNumber: 48
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 5
	}, this);
}
_c = Footer;
export default Footer;
var _c;
$RefreshReg$(_c, "Footer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Footer.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/herli/task-manager-react/frontend/src/components/Footer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/herli/task-manager-react/frontend/src/components/Footer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/herli/task-manager-react/frontend/src/components/Footer.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFNQSxTQUFTLE9BQU8sRUFBRSxPQUFPLFdBQVcsV0FBd0I7Q0FDMUQsT0FDRSx3QkFBQyxVQUFEO0VBQVEsV0FBVTtZQUFsQjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FBNkIsV0FBTyx3QkFBQyxRQUFELFlBQU8sTUFBWTs7OztZQUFNOzs7Ozs7R0FDN0Qsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUE2QixpQkFBYSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFhO0lBQWdCOzs7O1lBQU07Ozs7OztHQUM3Rix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQTZCLGdCQUFZLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWdCO0lBQWM7Ozs7WUFBTTs7Ozs7O0VBQ3ZGOzs7Ozs7QUFFWjs7QUFDQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkZvb3Rlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsidHlwZSBGb290ZXJQcm9wcyA9IHtcclxuICB0b3RhbDogbnVtYmVyO1xyXG4gIGNvbXBsZXRlZDogbnVtYmVyO1xyXG4gIHBlbmRpbmc6IG51bWJlcjtcclxufTtcclxuXHJcbmZ1bmN0aW9uIEZvb3Rlcih7IHRvdGFsLCBjb21wbGV0ZWQsIHBlbmRpbmcgfTogRm9vdGVyUHJvcHMpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGZvb3RlciBjbGFzc05hbWU9XCJhcHAtZm9vdGVyXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9vdGVyLXN0YXRcIj5Ub3RhbDogPHNwYW4+e3RvdGFsfTwvc3Bhbj48L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXItc3RhdFwiPkNvbXBsZXRhZGFzOiA8c3BhbiBjbGFzc05hbWU9XCJzdGF0LWRvbmVcIj57Y29tcGxldGVkfTwvc3Bhbj48L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXItc3RhdFwiPlBlbmRpZW50ZXM6IDxzcGFuIGNsYXNzTmFtZT1cInN0YXQtcGVuZGluZ1wiPntwZW5kaW5nfTwvc3Bhbj48L2Rpdj5cclxuICAgIDwvZm9vdGVyPlxyXG4gICk7XHJcbn1cclxuZXhwb3J0IGRlZmF1bHQgRm9vdGVyOyJdfQ==