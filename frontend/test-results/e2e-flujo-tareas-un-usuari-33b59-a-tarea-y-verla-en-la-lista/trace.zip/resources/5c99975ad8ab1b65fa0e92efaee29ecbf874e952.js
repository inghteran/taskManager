import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TaskCard.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/herli/task-manager-react/frontend/src/components/TaskCard.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f1ab0bd5";
function TaskCard({ task, onDeleteTask, onToggleTask }) {
	return /* @__PURE__ */ _jsxDEV(
		"div",
		// Si la tarea está completada, el CSS le aplicará opacidad y una línea encima
		{
			className: `task-card ${task.completed ? "completed" : ""}`,
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "task-content",
				children: [/* @__PURE__ */ _jsxDEV("input", {
					type: "checkbox",
					className: "task-checkbox",
					checked: task.completed,
					onChange: () => onToggleTask(task.id)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "task-text",
					children: task.text
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 7
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				className: "delete-btn",
				onClick: () => onDeleteTask(task.id),
				children: "Eliminar"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 7
			}, this)]
		},
		void 0,
		true,
		{
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 5
		},
		this
	);
}
_c = TaskCard;
export default TaskCard;
var _c;
$RefreshReg$(_c, "TaskCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/TaskCard.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/herli/task-manager-react/frontend/src/components/TaskCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/herli/task-manager-react/frontend/src/components/TaskCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/herli/task-manager-react/frontend/src/components/TaskCard.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFhQSxTQUFTLFNBQVMsRUFBRSxNQUFNLGNBQWMsZ0JBQStCO0NBQ3JFLE9BRUU7RUFBQzs7RUFBRDtHQUFLLFdBQVcsYUFBYSxLQUFLLFlBQVksY0FBYzthQUE1RCxDQUdFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxTQUFEO0tBQ0UsTUFBSztLQUNMLFdBQVU7S0FDVixTQUFTLEtBQUs7S0FDZCxnQkFBZ0IsYUFBYSxLQUFLLEVBQUU7SUFDckM7Ozs7Y0FFRCx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFhLEtBQUs7SUFBVzs7OztZQUMxQzs7Ozs7YUFHTCx3QkFBQyxVQUFEO0lBQVEsV0FBVTtJQUFhLGVBQWUsYUFBYSxLQUFLLEVBQUU7Y0FBRztHQUU3RDs7OztXQUVMOzs7Ozs7Ozs7OztBQUVUOztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVGFza0NhcmQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8vIDEuIExlIGRlY2ltb3MgYSBUeXBlU2NyaXB0IHF1w6kgZGF0b3MgbmVjZXNpdGEgZXN0ZSBjb21wb25lbnRlIHBhcmEgZXhpc3RpclxyXG50eXBlIFRhc2sgPSB7XHJcbiAgaWQ6IG51bWJlcjtcclxuICB0ZXh0OiBzdHJpbmc7XHJcbiAgY29tcGxldGVkOiBib29sZWFuO1xyXG59O1xyXG5cclxudHlwZSBUYXNrQ2FyZFByb3BzID0ge1xyXG4gIHRhc2s6IFRhc2s7ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBMYSB0YXJlYSBpbmRpdmlkdWFsIHF1ZSB2YSBhIGRpYnVqYXJcclxuICBvbkRlbGV0ZVRhc2s6IChpZDogbnVtYmVyKSA9PiB2b2lkOyAgICAgLy8gTGEgZnVuY2nDs24gcGFyYSBhdmlzYXIgcXVlIHF1aWVyZW4gYm9ycmFyXHJcbiAgb25Ub2dnbGVUYXNrOiAoaWQ6IG51bWJlcikgPT4gdm9pZDsgICAgIC8vIExhIGZ1bmNpw7NuIHBhcmEgYXZpc2FyIHF1ZSBxdWllcmVuIHRhY2hhclxyXG59O1xyXG5cclxuZnVuY3Rpb24gVGFza0NhcmQoeyB0YXNrLCBvbkRlbGV0ZVRhc2ssIG9uVG9nZ2xlVGFzayB9OiBUYXNrQ2FyZFByb3BzKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIC8vIFNpIGxhIHRhcmVhIGVzdMOhIGNvbXBsZXRhZGEsIGVsIENTUyBsZSBhcGxpY2Fyw6Egb3BhY2lkYWQgeSB1bmEgbMOtbmVhIGVuY2ltYVxyXG4gICAgPGRpdiBjbGFzc05hbWU9e2B0YXNrLWNhcmQgJHt0YXNrLmNvbXBsZXRlZCA/IFwiY29tcGxldGVkXCIgOiBcIlwifWB9PlxyXG4gICAgICBcclxuICAgICAgey8qIFNFQ0NJw5NOIElaUVVJRVJEQTogQ2hlY2tib3ggKyBUZXh0byAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0YXNrLWNvbnRlbnRcIj5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJ0YXNrLWNoZWNrYm94XCJcclxuICAgICAgICAgIGNoZWNrZWQ9e3Rhc2suY29tcGxldGVkfSAvLyBTaSBlc3TDoSBlbiB0cnVlIGVuIGxhIG1lbW9yaWEsIGFwYXJlY2Vyw6EgbWFyY2Fkb1xyXG4gICAgICAgICAgb25DaGFuZ2U9eygpID0+IG9uVG9nZ2xlVGFzayh0YXNrLmlkKX0gLy8gQWwgaGFjZXIgY2xpYywgZWplY3V0YSBsYSBmdW5jacOzbiBkZWwgcGFkcmVcclxuICAgICAgICAvPlxyXG4gICAgICAgIHsvKiBBcXXDrSBpbXByaW1pbW9zIGRlIGZvcm1hIGRpbsOhbWljYSBlbCB0ZXh0byB1c2FuZG8gbGxhdmVzIHt9ICovfVxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRhc2stdGV4dFwiPnt0YXNrLnRleHR9PC9zcGFuPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBTRUNDScOTTiBERVJFQ0hBOiBCb3TDs24gZGUgZWxpbWluYXIgKi99XHJcbiAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiZGVsZXRlLWJ0blwiIG9uQ2xpY2s9eygpID0+IG9uRGVsZXRlVGFzayh0YXNrLmlkKX0+XHJcbiAgICAgICAgRWxpbWluYXJcclxuICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgVGFza0NhcmQ7Il19