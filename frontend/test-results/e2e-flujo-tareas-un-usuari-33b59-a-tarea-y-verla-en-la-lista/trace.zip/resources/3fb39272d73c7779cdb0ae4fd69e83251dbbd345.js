import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/EmptyState.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/herli/task-manager-react/frontend/src/components/EmptyState.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f1ab0bd5";
function EmptyState() {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "empty-state-container",
		children: /* @__PURE__ */ _jsxDEV("p", {
			className: "empty-state-text",
			children: " No hay tareas todavía. Agrega una nueva tarea."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 4,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 3,
		columnNumber: 5
	}, this);
}
_c = EmptyState;
// Asegúrate de que termine en punto y coma (;) y no en dos puntos (:)
export default EmptyState;
var _c;
$RefreshReg$(_c, "EmptyState");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/EmptyState.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/herli/task-manager-react/frontend/src/components/EmptyState.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/herli/task-manager-react/frontend/src/components/EmptyState.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/herli/task-manager-react/frontend/src/components/EmptyState.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxTQUFTLGFBQWE7Q0FDcEIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLEtBQUQ7R0FBRyxXQUFVO2FBQW1CO0VBQWtEOzs7OztDQUMvRTs7Ozs7QUFFVDs7O0FBR0EsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJFbXB0eVN0YXRlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJmdW5jdGlvbiBFbXB0eVN0YXRlKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImVtcHR5LXN0YXRlLWNvbnRhaW5lclwiPlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJlbXB0eS1zdGF0ZS10ZXh0XCI+IE5vIGhheSB0YXJlYXMgdG9kYXbDrWEuIEFncmVnYSB1bmEgbnVldmEgdGFyZWEuPC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuLy8gQXNlZ8O6cmF0ZSBkZSBxdWUgdGVybWluZSBlbiBwdW50byB5IGNvbWEgKDspIHkgbm8gZW4gZG9zIHB1bnRvcyAoOilcclxuZXhwb3J0IGRlZmF1bHQgRW1wdHlTdGF0ZTsiXX0=