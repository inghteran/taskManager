import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Header.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/herli/task-manager-react/frontend/src/components/Header.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f1ab0bd5";
function Header() {
	return /* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("h1", { children: "Task Manager Yeah" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 4,
		columnNumber: 13
	}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Mi primera App" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 13
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 3,
		columnNumber: 9
	}, this);
}
_c = Header;
export default Header;
var _c;
$RefreshReg$(_c, "Header");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Header.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/herli/task-manager-react/frontend/src/components/Header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/herli/task-manager-react/frontend/src/components/Header.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/herli/task-manager-react/frontend/src/components/Header.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxTQUFTLFNBQVM7Q0FDZCxPQUNJLHdCQUFDLFVBQUQsYUFDSSx3QkFBQyxNQUFELFlBQUksb0JBQXFCOzs7O1dBQ3pCLHdCQUFDLEtBQUQsWUFBRyxpQkFBaUI7Ozs7U0FDaEI7Ozs7O0FBRWhCOztBQUNBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSGVhZGVyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJmdW5jdGlvbiBIZWFkZXIoKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxoZWFkZXI+XHJcbiAgICAgICAgICAgIDxoMT5UYXNrIE1hbmFnZXIgWWVhaDwvaDE+XHJcbiAgICAgICAgICAgIDxwPk1pIHByaW1lcmEgQXBwPC9wPlxyXG4gICAgICAgIDwvaGVhZGVyPlxyXG4gICAgKTtcclxufVxyXG5leHBvcnQgZGVmYXVsdCBIZWFkZXI7Il19